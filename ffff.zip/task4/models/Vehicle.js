let vehicles = []; // In-memory data
module.exports = vehicles;
